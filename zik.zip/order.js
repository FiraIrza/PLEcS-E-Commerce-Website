function addItem(event) {
    var row = event.target.parentNode.parentNode;
    var quantityInput = row.querySelector('input[type="number"]');
    var quantity = parseInt(quantityInput.value);

    quantityInput.value = quantity + 1;
    updateTotal(row);
    updateCartTotal(); // Added this line to update the cart total when an item is added
    updateCheckoutButton();
    updateEmptyCartText();
}

function updateTotal(row) {
    var priceElement = row.querySelector('td:nth-child(2)');
    var quantityElement = row.querySelector('td:nth-child(3)');
    var totalElement = row.querySelector('td:nth-child(4)');

    var price = parseFloat(priceElement.textContent.substring(1));
    var quantity = parseInt(quantityElement.querySelector('input[type="number"]').value);

    totalElement.textContent = '$' + (price * quantity).toFixed(2);
}

function removeItem(event) {
    var row = event.target.parentNode.parentNode;
    var quantityInput = row.querySelector('input[type="number"]');
    var quantity = parseInt(quantityInput.value);

    if (quantity > 1) {
        quantityInput.value = quantity - 1;
        updateTotal(row);
    } else {
        row.parentNode.removeChild(row);
    }
    let cartTableBody = document.getElementById('cartTableBody');
    let totalAmountSection = document.getElementById('totalAmountSection');

    if (cartTableBody.childElementCount === 1)
        totalAmountSection.style.display = 'none';

    updateCartTotal(); // Added this line to update the cart total when an item is removed
    updateCheckoutButton();
    updateEmptyCartText();
}

function updateCartTotal() {
    var total = 0;
    var cartTableRows = document.querySelectorAll('#cartTableBody tr');

    cartTableRows.forEach(function(row) {
        var totalElement = row.querySelector('td:nth-child(4)');
        var totalPrice = parseFloat(totalElement.textContent.substring(1));
        total += totalPrice;
    });

    var cartTotalElement = document.querySelector('.cart-total h2');
    cartTotalElement.textContent = '$' + total.toFixed(2);

    // Check if the cart is empty
    if (document.getElementById('cartTableBody').innerHTML === '') {
        // Hide the checkout button
        document.getElementById('checkoutBtn').style.display = 'none';
    } else {
        // Show the checkout button
        document.getElementById('checkoutBtn').style.display = 'inline';
    }
}

function proceedToCheckout() {
    alert('Your order has been successfully submitted!');

    // Check if the cart is empty
    if (document.getElementById('cartTableBody').innerHTML === '') {
        // Hide the checkout button
        document.getElementById('checkoutBtn').style.display = 'none';
    }
}

function updateCheckoutButton() {
    var cartTableBody = document.getElementById('cartTableBody');
    var checkoutBtn = document.getElementById('checkoutBtn');

    if (cartTableBody.getElementsByTagName('tr').length === 0) {
        checkoutBtn.style.display = 'none';
    } else {
        checkoutBtn.style.display = 'inline';
    }
}

function updateEmptyCartText() {
    var cartTableBody = document.getElementById('cartTableBody');
    var emptyCartText = document.getElementById('emptyCartText');

    if (cartTableBody.getElementsByTagName('tr').length === 0) {
        emptyCartText.style.display = 'block';
    } else {
        emptyCartText.style.display = 'none';
    }
}

function proceedToCheckout() {
    // Redirect to the checkout page
    window.location.href = "payment.html";

    // Show an alert box with a message
    alert('Your order has been successfully submitted!');

    // Check if the cart is empty
    if (document.getElementById('cartTableBody').innerHTML === '') {
        // Hide the checkout button
        document.getElementById('checkoutBtn').style.display = 'none';
    }
}